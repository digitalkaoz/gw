<?php

namespace Bolt\Exception;

/**
 * Signals an error in the parser.
 */
class PermissionParserException extends \Exception
{
}
